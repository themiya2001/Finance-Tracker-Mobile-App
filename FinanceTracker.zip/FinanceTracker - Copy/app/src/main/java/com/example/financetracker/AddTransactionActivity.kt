package com.example.financetracker

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class AddTransactionActivity : AppCompatActivity() {

    lateinit var etTitle: EditText
    lateinit var etAmount: EditText
    lateinit var spinnerCategory: Spinner
    lateinit var etDate: EditText
    lateinit var btnSave: Button

    val categories = arrayOf("Food", "Transport", "Bills", "Entertainment", "Education", "Health", "Other")

    companion object {
        const val PREFS_NAME = "finance_data"
        const val TRANSACTIONS_KEY = "transactions"
    }

    var selectedStorageDate = "" // To store date in yyyy-MM-dd format

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_transaction)

        etTitle = findViewById(R.id.etTitle)
        etAmount = findViewById(R.id.etAmount)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        etDate = findViewById(R.id.etDate)
        btnSave = findViewById(R.id.btnSave)

        spinnerCategory.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)

        // Date picker
        etDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            val datePicker = DatePickerDialog(this,
                { _, year, month, day ->
                    val displayDate = String.format("%02d/%02d/%d", day, month + 1, year)
                    val storageDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                        .format(Calendar.getInstance().apply {
                            set(year, month, day)
                        }.time)

                    etDate.setText(displayDate)
                    selectedStorageDate = storageDate
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )
            datePicker.show()
        }

        btnSave.setOnClickListener {
            saveTransaction()
        }
    }

    private fun saveTransaction() {
        val title = etTitle.text.toString().trim()
        val amountText = etAmount.text.toString().trim()
        val category = spinnerCategory.selectedItem.toString()
        val displayDate = etDate.text.toString().trim()

        if (title.isBlank() || amountText.isBlank() || displayDate.isBlank()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val amount: Double
        try {
            amount = amountText.toDouble()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        val transaction = JSONObject().apply {
            put("title", title)
            put("amount", amount)
            put("category", category)
            put("date", selectedStorageDate) // Save in yyyy-MM-dd format
        }

        val sharedPrefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = sharedPrefs.edit()

        val oldData = sharedPrefs.getString(TRANSACTIONS_KEY, "[]")
        val jsonArray = JSONArray(oldData)
        jsonArray.put(transaction)

        editor.putString(TRANSACTIONS_KEY, jsonArray.toString())
        editor.apply()

        Toast.makeText(this, "Transaction Saved", Toast.LENGTH_SHORT).show()

        // Navigate to MainActivity
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        finish()

        // Clear fields
        etTitle.text.clear()
        etAmount.text.clear()
        etDate.text.clear()
        spinnerCategory.setSelection(0)
        selectedStorageDate = ""

    }
}
