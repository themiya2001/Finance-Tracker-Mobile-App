package com.example.financetracker

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Set up button click listeners
        findViewById<LinearLayout>(R.id.btnAddTransaction).setOnClickListener {
            startActivity(Intent(this, AddTransactionActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.btnViewTransactions).setOnClickListener {
            startActivity(Intent(this, ViewTransactionsActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.btnBudget).setOnClickListener {
            startActivity(Intent(this, BudgetActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.btnSummary).setOnClickListener {
            startActivity(Intent(this, CategorySummaryActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.btnBackup).setOnClickListener {
            startActivity(Intent(this, BackupRestoreActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }
}