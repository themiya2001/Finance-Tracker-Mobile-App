package com.example.financetracker

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.snackbar.Snackbar
import org.json.JSONArray
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.*

class CategorySummaryActivity : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var tvTotalAmount: TextView
    private lateinit var tvCategoryCount: TextView
    private lateinit var rootLayout: View

    companion object {
        private const val PREFS_NAME = "finance_data"
        private const val TRANSACTIONS_KEY = "transactions"
        private val currencyFormat: DecimalFormat = NumberFormat.getCurrencyInstance() as DecimalFormat
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_summary)

        initViews()

        // Customize the currency format
        currencyFormat.apply {
            decimalFormatSymbols = decimalFormatSymbols.apply {
                currencySymbol = "Rs."
            }
            minimumFractionDigits = 2
            maximumFractionDigits = 2
        }

        loadCategorySummary()
    }

    private fun initViews() {
        listView = findViewById(R.id.listViewCategorySummary)
        tvTotalAmount = findViewById(R.id.tvTotalAmount)
        tvCategoryCount = findViewById(R.id.tvCategoryCount)
        rootLayout = findViewById(android.R.id.content)
    }

    private fun loadCategorySummary() {
        try {
            val sharedPrefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val jsonData = sharedPrefs.getString(TRANSACTIONS_KEY, "[]") ?: "[]"

            val jsonArray = try {
                JSONArray(jsonData)
            } catch (e: Exception) {
                showError("Error loading transaction data")
                JSONArray()
            }

            if (jsonArray.length() == 0) {
                showEmptyState()
                return
            }

            val categoryMap = mutableMapOf<String, Double>()
            var grandTotal = 0.0

            for (i in 0 until jsonArray.length()) {
                try {
                    val obj = jsonArray.getJSONObject(i)
                    val category = obj.optString("category", "Uncategorized")
                    val amount = obj.optDouble("amount", 0.0)

                    categoryMap[category] = categoryMap.getOrDefault(category, 0.0) + amount
                    grandTotal += amount
                } catch (e: Exception) {
                    // Skip malformed entries
                    continue
                }
            }

            updateSummaryViews(categoryMap, grandTotal)
            setupListView(categoryMap)

        } catch (e: Exception) {
            showError("Failed to load summary")
        }
    }

    private fun updateSummaryViews(categoryMap: Map<String, Double>, grandTotal: Double) {
        tvTotalAmount.text = currencyFormat.format(grandTotal)
        tvCategoryCount.text = categoryMap.size.toString()
    }

    private fun setupListView(categoryMap: Map<String, Double>) {
        // Sort by amount (descending)
        val sortedEntries = categoryMap.entries.sortedByDescending { it.value }

        // Create formatted strings with percentage
        val grandTotal = categoryMap.values.sum()
        val summaryList = sortedEntries.map { (category, total) ->
            val percentage = if (grandTotal > 0) (total / grandTotal * 100).toInt() else 0
            "$category: ${currencyFormat.format(total)} ($percentage%)"
        }

        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            summaryList
        )
        listView.adapter = adapter
    }

    private fun showEmptyState() {
        Snackbar.make(rootLayout, "No transactions found", Snackbar.LENGTH_INDEFINITE)
            .setAction("Add Transaction") {
                // Start AddTransactionActivity
                finish() // Close this activity
            }
            .setBackgroundTint(ContextCompat.getColor(this, R.color.colorPrimary))
            .setTextColor(ContextCompat.getColor(this, android.R.color.white))
            .setActionTextColor(ContextCompat.getColor(this, R.color.green))
            .show()
    }

    private fun showError(message: String) {
        Snackbar.make(rootLayout, message, Snackbar.LENGTH_LONG)
            .setBackgroundTint(ContextCompat.getColor(this, R.color.red))
            .setTextColor(ContextCompat.getColor(this, android.R.color.white))
            .show()
    }
}