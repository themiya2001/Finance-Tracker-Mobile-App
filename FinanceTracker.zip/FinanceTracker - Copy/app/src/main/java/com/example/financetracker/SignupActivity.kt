package com.example.financetracker

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Patterns
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SignupActivity : AppCompatActivity() {

    private lateinit var sharedPref: SharedPreferences
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnSignup: Button
    private lateinit var tvLoginRedirect: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        sharedPref = getSharedPreferences("user_data", MODE_PRIVATE)

        etEmail = findViewById(R.id.etSignupEmail)
        etPassword = findViewById(R.id.etSignupPassword)
        btnSignup = findViewById(R.id.btnSignup)
        tvLoginRedirect = findViewById(R.id.tvLoginRedirect)

        btnSignup.setOnClickListener {
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            // Input Validation
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val existingEmail = sharedPref.getString("user_email", "")
            if (email == existingEmail) {
                Toast.makeText(this, "This email is already registered. Please log in.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Save new user credentials
            with(sharedPref.edit()) {
                putString("user_email", email)
                putString("user_password", password)
                apply()
            }

            Toast.makeText(this, "Account created! Please log in.", Toast.LENGTH_SHORT).show()

            // Redirect to LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }

        tvLoginRedirect.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
