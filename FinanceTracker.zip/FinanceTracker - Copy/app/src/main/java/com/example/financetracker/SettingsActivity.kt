package com.example.financetracker


import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.financetracker.LoginActivity
import com.example.financetracker.R

class SettingsActivity : AppCompatActivity() {

    private lateinit var sharedPrefs: SharedPreferences
    private lateinit var spCurrency: Spinner
    private lateinit var etNewBudget: EditText
    private lateinit var switchNotifications: Switch
    private lateinit var btnSave: Button
    private lateinit var btnLogout: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        sharedPrefs = getSharedPreferences("FinancePrefs", MODE_PRIVATE)

        spCurrency = findViewById(R.id.spCurrency)
        etNewBudget = findViewById(R.id.etNewBudget)
        switchNotifications = findViewById(R.id.switchNotifications)
        btnSave = findViewById(R.id.btnSaveSettings)
        btnLogout = findViewById(R.id.btnLogout)

        // Setup Spinner
        val currencies = arrayOf("LKR", "USD", "EUR", "INR")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, currencies)
        spCurrency.adapter = adapter

        // Load saved settings
        val savedCurrency = sharedPrefs.getString("currency", "LKR")
        val savedBudget = sharedPrefs.getFloat("budget", 0f)
        val notificationsEnabled = sharedPrefs.getBoolean("notifications", true)

        val currencyIndex = currencies.indexOf(savedCurrency).takeIf { it >= 0 } ?: 0
        spCurrency.setSelection(currencyIndex)
        etNewBudget.setText(savedBudget.toString())
        switchNotifications.isChecked = notificationsEnabled

        // Save settings
        btnSave.setOnClickListener {
            val budgetValue = etNewBudget.text.toString().toFloatOrNull() ?: 0f

            sharedPrefs.edit().apply {
                putString("currency", spCurrency.selectedItem.toString())
                putFloat("budget", budgetValue)
                putBoolean("notifications", switchNotifications.isChecked)
                apply()
            }

            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }

        // Logout and clear shared prefs
        btnLogout.setOnClickListener {
            sharedPrefs.edit().clear().apply()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
