package com.example.financetracker

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import org.json.JSONArray

class BudgetActivity : AppCompatActivity() {

    lateinit var etBudget: TextInputEditText
    lateinit var btnSaveBudget: MaterialButton
    lateinit var tvBudgetAmount: TextView
    lateinit var tvSpentAmount: TextView
    lateinit var tvRemainingAmount: TextView
    lateinit var progressBar: LinearProgressIndicator
    lateinit var tvProgressText: TextView
    lateinit var cardWarning: MaterialCardView
    lateinit var tvWarningText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget)

        // Initialize views
        etBudget = findViewById(R.id.etBudget)
        btnSaveBudget = findViewById(R.id.btnSaveBudget)
        tvBudgetAmount = findViewById(R.id.tvBudgetAmount)
        tvSpentAmount = findViewById(R.id.tvSpentAmount)
        tvRemainingAmount = findViewById(R.id.tvRemainingAmount)
        progressBar = findViewById(R.id.progressBar)
        tvProgressText = findViewById(R.id.tvProgressText)
        cardWarning = findViewById(R.id.cardWarning)
        tvWarningText = findViewById(R.id.tvWarningText)

        val sharedPrefs = getSharedPreferences("finance_data", Context.MODE_PRIVATE)
        val savedBudget = sharedPrefs.getFloat("monthly_budget", 0f)
        if (savedBudget > 0f) {
            etBudget.setText(savedBudget.toString())
        }

        btnSaveBudget.setOnClickListener {
            val budgetText = etBudget.text.toString().trim()
            val budget = budgetText.toFloatOrNull()
            if (budget != null && budget > 0) {
                sharedPrefs.edit().putFloat("monthly_budget", budget).apply()
                Toast.makeText(this, "Budget Saved", Toast.LENGTH_SHORT).show()
                showSpendingSummary()  // Update budget summary
            } else {
                Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show()
            }
        }


        showSpendingSummary()
    }

    private fun showSpendingSummary() {
        val sharedPrefs = getSharedPreferences("finance_data", Context.MODE_PRIVATE)
        val jsonData = sharedPrefs.getString("transactions", "[]")
        val budget = sharedPrefs.getFloat("monthly_budget", 0f)

        // Handle empty or missing transaction data
        val jsonArray = try {
            JSONArray(jsonData)
        } catch (e: Exception) {
            JSONArray()  // Default to empty if there's an issue with the data
        }

        var totalSpending = 0.0


        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            totalSpending += obj.getDouble("amount")
        }

        val remaining = budget - totalSpending
        val percent = if (budget > 0) (totalSpending / budget * 100).toInt() else 0

        // Update UI
        tvBudgetAmount.text = "Rs.%.2f".format(budget)
        tvSpentAmount.text = "Rs.%.2f".format(totalSpending)
        tvRemainingAmount.text = "Rs.%.2f".format(remaining)
        progressBar.progress = percent
        tvProgressText.text = "$percent% of budget used"

        // Show/hide warning if spending is over 90% of the budget
        if (budget > 0 && totalSpending >= budget * 0.9) {
            cardWarning.visibility = View.VISIBLE
            tvWarningText.text = "⚠️ You're approaching your budget limit!"
        } else {
            cardWarning.visibility = View.GONE
        }
    }
}
