package com.example.financetracker

import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

class ViewTransactionsActivity : AppCompatActivity() {

    lateinit var listView: ListView
    lateinit var transactionList: MutableList<JSONObject>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_transactions)

        listView = findViewById(R.id.listViewTransactions)

        loadTransactions()
    }

    private fun loadTransactions() {
        val sharedPrefs = getSharedPreferences("finance_data", Context.MODE_PRIVATE)
        val jsonData = sharedPrefs.getString("transactions", "[]")
        val jsonArray = JSONArray(jsonData)

        transactionList = mutableListOf()
        for (i in 0 until jsonArray.length()) {
            transactionList.add(jsonArray.getJSONObject(i))
        }

        val adapter = TransactionAdapter(this, transactionList)
        listView.adapter = adapter
    }

    inner class TransactionAdapter(
        private val context: Context,
        private val transactions: MutableList<JSONObject>
    ) : BaseAdapter(), ListAdapter {

        override fun getCount(): Int = transactions.size

        override fun getItem(position: Int): Any = transactions[position]

        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val holder: ViewHolder

            if (convertView == null) {
                view = LayoutInflater.from(context).inflate(R.layout.transaction_item, parent, false)
                holder = ViewHolder()
                holder.tvTransactionSummary = view.findViewById(R.id.tvTransactionSummary)
                holder.btnEdit = view.findViewById(R.id.btnEdit)
                holder.btnDelete = view.findViewById(R.id.btnDelete)
                view.tag = holder
            } else {
                view = convertView
                holder = view.tag as ViewHolder
            }

            val transaction = transactions[position]
            val summary = "Title: ${transaction.getString("title")}\n" +
                    "Amount: ${transaction.getDouble("amount")}\n" +
                    "Category: ${transaction.getString("category")}\n" +
                    "Date: ${transaction.getString("date")}"
            holder.tvTransactionSummary?.text = summary

            holder.btnEdit?.setOnClickListener {
                showEditDialog(transaction, position)
            }

            holder.btnDelete?.setOnClickListener {
                AlertDialog.Builder(context)
                    .setTitle("Delete Transaction")
                    .setMessage("Are you sure you want to delete this transaction?")
                    .setPositiveButton("Yes") { _: DialogInterface, _: Int ->
                        deleteTransaction(position)
                    }
                    .setNegativeButton("No", null)
                    .show()
            }

            return view
        }

        private fun showEditDialog(transaction: JSONObject, position: Int) {
            val inflater = LayoutInflater.from(context)
            val dialogView = inflater.inflate(R.layout.dialog_edit_transaction, null)

            val editTitle = dialogView.findViewById<EditText>(R.id.editTitle)
            val editAmount = dialogView.findViewById<EditText>(R.id.editAmount)
            val editCategory = dialogView.findViewById<EditText>(R.id.editCategory)
            val editDate = dialogView.findViewById<EditText>(R.id.editDate)

            editTitle.setText(transaction.getString("title"))
            editAmount.setText(transaction.getDouble("amount").toString())
            editCategory.setText(transaction.getString("category"))
            editDate.setText(transaction.getString("date"))

            AlertDialog.Builder(context)
                .setTitle("Edit Transaction")
                .setView(dialogView)
                .setPositiveButton("Update") { _, _ ->
                    val newTitle = editTitle.text.toString()
                    val newAmount = editAmount.text.toString().toDoubleOrNull()
                    val newCategory = editCategory.text.toString()
                    val newDate = editDate.text.toString()

                    if (newTitle.isBlank() || newAmount == null || newCategory.isBlank() || newDate.isBlank()) {
                        Toast.makeText(context, "All fields are required", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }

                    transaction.put("title", newTitle)
                    transaction.put("amount", newAmount)
                    transaction.put("category", newCategory)
                    transaction.put("date", newDate)

                    saveTransactions()
                    notifyDataSetChanged()
                    Toast.makeText(context, "Transaction updated", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        private fun saveTransactions() {
            val sharedPrefs = context.getSharedPreferences("finance_data", Context.MODE_PRIVATE)
            val editor = sharedPrefs.edit()
            val jsonArray = JSONArray()

            for (transaction in transactions) {
                jsonArray.put(transaction)
            }

            editor.putString("transactions", jsonArray.toString())
            editor.apply()
        }

        private fun deleteTransaction(position: Int) {
            transactions.removeAt(position)
            notifyDataSetChanged()
            saveTransactions()
            Toast.makeText(context, "Transaction deleted", Toast.LENGTH_SHORT).show()
        }

        inner class ViewHolder {
            var tvTransactionSummary: TextView? = null
            var btnEdit: ImageButton? = null
            var btnDelete: ImageButton? = null
        }
    }
}
