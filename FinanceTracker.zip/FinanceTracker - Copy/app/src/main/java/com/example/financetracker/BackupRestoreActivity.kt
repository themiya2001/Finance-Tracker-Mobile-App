package com.example.financetracker

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.*

class BackupRestoreActivity : AppCompatActivity() {

    private lateinit var btnBackup: Button
    private lateinit var btnRestore: Button
    private lateinit var tvStatus: TextView

    private val fileName = "finance_backup.txt"
    private val TAG = "BackupRestore"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backup_restore)

        btnBackup = findViewById(R.id.btnBackup)
        btnRestore = findViewById(R.id.btnRestore)
        tvStatus = findViewById(R.id.tvBackupStatus)

        btnBackup.setOnClickListener { backupData() }
        btnRestore.setOnClickListener { restoreData() }
    }

    private fun backupData() {
        val sharedPrefs = getSharedPreferences("finance_data", Context.MODE_PRIVATE)
        val data = sharedPrefs.getString("transactions", "[]")

        try {
            openFileOutput(fileName, Context.MODE_PRIVATE).use { output ->
                output.write(data?.toByteArray())
            }
            tvStatus.text = "Backup successful!"
            Toast.makeText(this, "Backup completed.", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            tvStatus.text = "Backup failed."
            Toast.makeText(this, "Error: Backup failed!", Toast.LENGTH_SHORT).show()
            Log.e(TAG, "Backup Error: ${e.message}", e)
        }
    }

    private fun restoreData() {
        try {
            val restoredData = openFileInput(fileName).bufferedReader().use { it.readText() }

            val sharedPrefs = getSharedPreferences("finance_data", Context.MODE_PRIVATE)
            sharedPrefs.edit().putString("transactions", restoredData).apply()

            tvStatus.text = "Restore successful!"
            Toast.makeText(this, "Data restored.", Toast.LENGTH_SHORT).show()
        } catch (e: FileNotFoundException) {
            tvStatus.text = "No backup file found."
            Toast.makeText(this, "No backup available!", Toast.LENGTH_SHORT).show()
            Log.w(TAG, "Restore Warning: File not found", e)
        } catch (e: IOException) {
            tvStatus.text = "Restore failed."
            Toast.makeText(this, "Error: Restore failed!", Toast.LENGTH_SHORT).show()
            Log.e(TAG, "Restore Error: ${e.message}", e)
        }
    }
}
